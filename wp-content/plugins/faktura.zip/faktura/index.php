<?php

/**
 * Plugin Name: Lagom Faktura
 * Author: Lagom fula hattar 
 * */

add_action('plugins_loaded', 'init_your_gateway_class');

function add_your_gateway_class($methods)
{
  $methods[] = 'WC_Gateway_Your_Gateway';
  return $methods;
}

add_filter('woocommerce_payment_gateways', 'add_your_gateway_class');


function my_custom_checkout_field($checkout)
{
  echo '<div id="my_custom_checkout_field"><h2>' . __('Personnummer') . '</h2>';

  woocommerce_form_field('my_field_name', array(
    'type'          => 'password',
    'class'         => array('my-field-class form-row-wide'),
    'label'         => __('För betalning med faktura'),
    'placeholder'   => __('xxxxxx - xxxx'),
  ), $checkout->get_value('my_field_name'));

  echo '</div>';
}

function isValid($personNumber)
{
  settype($personNumber, 'string');
  $sumTable = array(
    array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9),
    array(0, 2, 4, 6, 8, 1, 3, 5, 7, 9)
  );
  $sum = 0;
  $flip = 0;
  for ($i = strlen($personNumber) - 1; $i >= 0; $i--) {
    $sum += $sumTable[$flip++ & 0x1][$personNumber[$i]];
  }
  return $sum % 10 === 0;
}

add_action('woocommerce_checkout_update_order_meta', 'my_custom_checkout_field_update_order_meta');

function my_custom_checkout_field_update_order_meta($order_id)
{
  if (!empty($_POST['my_field_name'])) {
    update_post_meta($order_id, 'My Field', sanitize_text_field($_POST['my_field_name']));
  }
}


function init_your_gateway_class()
{
  class WC_Gateway_Your_Gateway extends WC_Payment_Gateway
  {
    public function __construct()
    {
      $this->id = 'abc123hej';
      $this->method_title = 'Lagom Fakura';
      $this->method_description = '14 dagar Faktura';
      $this->has_fields = true;


      $this->init_form_fields();
      $this->init_settings();

      $this->title = $this->get_option('title');
      $this->description = $this->get_option('description');
      $this->enabled = $this->get_option('enabled');

      add_action('woocommerce_after_order_notes', 'my_custom_checkout_field');
      add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
    }

    public function load_my_scripts()
    {
      wp_enqueue_script('script',   plugins_url("faktura/myScript.js"), [], false, true);
    }

    /*     public function payment_fields()
    {
      $input = '<input name="personnr"  type="number" />';
      echo $this->description . '<br>';
      echo $input;
    } */

    public function validate_fields()
    {
      return true;
    }

    public function init_form_fields()
    {
      $this->form_fields = array(
        'enabled' => array(
          'title' => __('Enable/Disable', 'woocommerce'),
          'type' => 'checkbox',
          'label' => __('Aktivera Betalning Med Faktura', 'woocommerce'),
          'default' => 'yes'
        ),
        'title' => array(
          'title' => __('Title', 'woocommerce'),
          'type' => 'text',
          'description' => __('This controls the title which the user sees during checkout.', 'woocommerce'),
          'default' => __('Cheque Payment', 'woocommerce'),
          'desc_tip'      => true,
        ),
        'description' => array(
          'title' => __('Customer Message', 'woocommerce'),
          'type' => 'textarea',
          'default' => ''
        )
      );
      add_action('woocommerce_update_options_payment_gateways', array(&$this, 'process_admin_options'));
    }


    function process_payment($order_id)
    {
      global $woocommerce;
      $order = new WC_Order($order_id);

      // Mark as on-hold (we're awaiting the cheque)
      $order->update_status('on-hold', __('Awaiting cheque payment', 'woocommerce'));

      $personNumber = $_POST['my_field_name'];

      if (isValid($personNumber)) {
        $paymentValid = true;
      } else {
        $paymentValid = false;
      }

      // Return thankyou redirect
      if ($paymentValid) {
        $woocommerce->cart->empty_cart();
        return array(
          'result' => 'success',
          'redirect' => $this->get_return_url($order)
        );
      } else {
        $error_message = 'Fel personnummer';
        wc_add_notice(__('Payment error:', 'woothemes') . $error_message, 'error');
        return;
      }
    }
  }
}




/* $this->id – Unique ID for your gateway, e.g., ‘your_gateway’
$this->icon – If you want to show an image next to the gateway’s name on the frontend, enter a URL to an image.
$this->has_fields – Bool. Can be set to true if you want payment fields to show on the checkout (if doing a direct integration).
$this->method_title – Title of the payment method shown on the admin page.
$this->method_description – Description for the payment method shown on the admin page.

 */
